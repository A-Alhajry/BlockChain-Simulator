package qu.master.blockchain.gui;

public class Constants {
	public static final String ValidBlockColor = "#DEEFD7";
	public static final String InvalidBlockColor = "#FADCDC";
}
